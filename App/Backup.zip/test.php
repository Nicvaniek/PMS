<!DOCTYPE html>
<html>
<body>

<?php
$a=array("a"=>"red","b"=>"green");
$a["indexname"] = "value";
print_r($a);
?>

</body>
</html>